import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Users, Mail, UserCheck, Search, Filter, MoreVertical, Edit, Key, ShieldOff, Globe, Database, Plus, ChevronDown, X, Shield, MapPin, Briefcase } from 'lucide-react'
import { cn } from '../../lib/utils'
import { useQuery } from '@tanstack/react-query'
import { useUserActions } from '../../hooks/useCrmMutations'
import { motion, AnimatePresence } from 'framer-motion'
import api from '../../services/api'

const UserModal = ({ isOpen, onClose, user = null, onSuccessRedirect }) => {
    const { addUser, updateUser } = useUserActions();
    const [formData, setFormData] = useState(user || {
        name: '',
        email: '',
        role: 'Counselor',
        client: 'EduCorp Inc.',
        country: 'India',
        team: 'Admissions',
        assignedChannels: 0
    });

    if (!isOpen) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        const payload = { ...formData, assignedChannels: parseInt(formData.assignedChannels) || 0 };
        if (user) {
            updateUser.mutate({ id: user.id, ...payload }, { onSuccess: onClose });
        } else {
            addUser.mutate(payload, { 
                onSuccess: () => {
                    onClose();
                    if (onSuccessRedirect) onSuccessRedirect();
                } 
            });
        }
    };

    const isPending = addUser.isPending || updateUser.isPending;

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }} className="bg-white rounded-[2rem] w-full max-w-lg overflow-hidden shadow-2xl mx-2 sm:mx-auto max-h-[85vh] overflow-y-auto no-scrollbar">
                <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-[#111827] text-white rounded-2xl shadow">
                            <Users size={20} />
                        </div>
                        <div>
                            <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight">{user ? 'Refine Identity' : 'Provision User'}</h3>
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Global Directory Protocol v2.4</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white rounded-xl transition-colors shadow-sm"><X size={20} className="text-gray-400" /></button>
                </div>

                <form onSubmit={handleSubmit} className="p-8 space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1 col-span-1 sm:col-span-2">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <UserCheck size={12} /> Full Name
                            </label>
                            <input
                                required
                                type="text"
                                value={formData.name}
                                onChange={e => setFormData({ ...formData, name: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all placeholder:text-gray-300"
                                placeholder="e.g. Alexander Pierce"
                            />
                        </div>
                        <div className="space-y-1 col-span-1 sm:col-span-2">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <Mail size={12} /> Email Address
                            </label>
                            <input
                                required
                                type="email"
                                value={formData.email}
                                onChange={e => setFormData({ ...formData, email: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all placeholder:text-gray-300"
                                placeholder="alex@nexus.com"
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <Shield size={12} /> Global Role
                            </label>
                            <select
                                value={formData.role}
                                onChange={e => setFormData({ ...formData, role: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all appearance-none cursor-pointer"
                            >
                                <option>Admin</option>
                                <option>Manager</option>
                                <option>Counselor</option>
                                <option>Team Leader</option>
                                <option>Support</option>
                            </select>
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <Database size={12} /> Primary Client
                            </label>
                            <select
                                value={formData.client}
                                onChange={e => setFormData({ ...formData, client: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all appearance-none cursor-pointer"
                            >
                                <option>EduCorp Inc.</option>
                                <option>HealthLine</option>
                                <option>Global Connect</option>
                                <option>Platform Staff</option>
                            </select>
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <MapPin size={12} /> Operational Country
                            </label>
                            <select
                                value={formData.country}
                                onChange={e => setFormData({ ...formData, country: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all appearance-none cursor-pointer"
                            >
                                <option>India</option>
                                <option>USA</option>
                                <option>UK</option>
                                <option>Italy</option>
                                <option>Global</option>
                            </select>
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <Briefcase size={12} /> Department / Team
                            </label>
                            <input
                                required
                                type="text"
                                value={formData.team}
                                onChange={e => setFormData({ ...formData, team: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all placeholder:text-gray-300"
                                placeholder="Operations"
                            />
                        </div>
                        <div className="space-y-1 col-span-1 sm:col-span-2">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-1">
                                <Globe size={12} /> Assigned Integrations (Nodes)
                            </label>
                            <input
                                required
                                type="number"
                                min="0"
                                value={formData.assignedChannels}
                                onChange={e => setFormData({ ...formData, assignedChannels: e.target.value })}
                                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-xs font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all placeholder:text-gray-300"
                                placeholder="0"
                            />
                        </div>
                    </div>

                    <div className="pt-4 flex gap-3">
                        <button
                            type="button"
                            onClick={onClose}
                            className="flex-1 py-4 border border-gray-100 rounded-2xl text-[10px] sm:text-xs font-black uppercase tracking-widest text-gray-400 hover:bg-gray-50 transition-all whitespace-nowrap truncate px-2"
                        >
                            Cancel
                        </button>
                        <button
                            disabled={isPending}
                            type="submit"
                            className="flex-1 py-4 bg-[#111827] text-white rounded-2xl text-[10px] sm:text-xs font-black uppercase tracking-widest hover:bg-black transition-all shadow disabled:opacity-50 whitespace-nowrap truncate px-2"
                        >
                            {isPending ? 'Deploying...' : user ? 'Sync Identity' : 'Authorize User'}
                        </button>
                    </div>
                </form>
            </motion.div>
        </motion.div>
    );
};

const GlobalUsers = () => {
    const navigate = useNavigate()
    const { toggleStatus, resetPassword, updateUser } = useUserActions()
    const [searchTerm, setSearchTerm] = useState('')
    const [roleFilter, setRoleFilter] = useState('All Roles')
    const [countryFilter, setCountryFilter] = useState('All Countries')
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [selectedUser, setSelectedUser] = useState(null)

    const { data: users = [], isLoading } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
            const res = await api.get('/users');
            const usersArray = res.data || res;
            return (Array.isArray(usersArray) ? usersArray : []).map(user => ({
                id: user.id,
                name: user.name || 'Unknown',
                email: user.email || '',
                // Backend returns role as object {id, name, description} — extract .name string
                role: typeof user.role === 'object' ? (user.role?.name || 'N/A') : (user.role || 'N/A'),
                client: user.client || user.organization?.name || 'Internal',
                country: user.country || 'Global',
                team: user.team || user.department || 'Staff',
                status: user.status || user.isActive ? 'Active' : 'Inactive',
                assignedChannels: user.assignedChannels || user._count?.channels || 0
            }));
        }
    })

    const filteredUsers = users.filter(user => {
        const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.client.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesRole = roleFilter === 'All Roles' || user.role === roleFilter
        const matchesCountry = countryFilter === 'All Countries' || user.country === countryFilter
        return matchesSearch && matchesRole && matchesCountry
    })


    const openEditModal = (user) => {
        setSelectedUser(user);
        setIsModalOpen(true);
    };

    const openAddModal = () => {
        setSelectedUser(null);
        setIsModalOpen(true);
    };

    return (
        <div className="space-y-12 pb-20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-8">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
                        <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">Master Directory</span>
                    </div>
                    <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase leading-none">Identity Registry</h1>
                    <p className="text-sm font-medium text-slate-500 mt-2 max-w-xl">Comprehensive management of global credentials across all territorial zones.</p>
                </div>
                <button
                    onClick={openAddModal}
                    className="w-full sm:w-auto h-14 px-10 bg-[#020617] text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] hover:bg-black transition-all shadow-2xl shadow-slate-900/20 flex items-center justify-center gap-4 active:scale-95 ring-1 ring-slate-800"
                >
                    <Plus size={18} />
                    <span>Provision Node</span>
                </button>
            </div>

            <div className="crm-card !p-6 flex flex-col lg:flex-row gap-6 items-center border-none shadow-2xl shadow-slate-200/50">
                <div className="relative flex-1 w-full group">
                    <Search size={18} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" />
                    <input
                        type="text"
                        placeholder="Identify node..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-14 pr-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-[10px] font-black uppercase tracking-widest focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:bg-white focus:border-indigo-200 transition-all placeholder:text-slate-300 shadow-inner"
                    />
                </div>
                <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
                    <div className="relative flex-1 sm:min-w-[180px]">
                        <select
                            value={roleFilter}
                            onChange={(e) => setRoleFilter(e.target.value)}
                            className="w-full pl-6 pr-12 py-4 bg-white border border-slate-100 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest appearance-none focus:outline-none focus:ring-4 focus:ring-indigo-500/10 cursor-pointer shadow-sm"
                        >
                            <option>All Roles</option>
                            <option>Admin</option>
                            <option>Manager</option>
                            <option>Counselor</option>
                        </select>
                        <ChevronDown size={14} className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none" />
                    </div>
                    <div className="relative flex-1 sm:min-w-[180px]">
                        <select
                            value={countryFilter}
                            onChange={(e) => setCountryFilter(e.target.value)}
                            className="w-full pl-6 pr-12 py-4 bg-white border border-slate-100 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest appearance-none focus:outline-none focus:ring-4 focus:ring-indigo-500/10 cursor-pointer shadow-sm"
                        >
                            <option>All Countries</option>
                            <option>India</option>
                            <option>USA</option>
                            <option>UK</option>
                        </select>
                        <ChevronDown size={14} className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none" />
                    </div>
                </div>
            </div>

            <div className="crm-card !p-0 overflow-hidden flex flex-col min-h-[500px] border-none shadow-2xl shadow-slate-200/50 w-full overflow-x-auto">
                <div className="overflow-x-auto w-full no-scrollbar">
                    <table className="w-full text-left border-collapse min-w-[1000px]">
                        <thead>
                            <tr className="bg-[#F9FAFB]/50">
                            <tr className="bg-[#F9FAFB]/50">
                                <th className="px-4 sm:px-10 py-6 font-black text-gray-400 uppercase text-[9px] tracking-[0.2em]">User Identity</th>
                                <th className="px-4 sm:px-10 py-6 font-black text-gray-400 uppercase text-[9px] tracking-[0.2em]">Protocol / State</th>
                                <th className="px-4 sm:px-10 py-6 font-black text-gray-400 uppercase text-[9px] tracking-[0.2em]">Client Cluster</th>
                                <th className="px-4 sm:px-10 py-6 font-black text-gray-400 uppercase text-[9px] tracking-[0.2em]">Infrastructure</th>
                                <th className="px-4 sm:px-10 py-6 text-right font-black text-gray-400 uppercase text-[9px] tracking-[0.2em]">Actions</th>
                            </tr>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[#E5E7EB]/50 text-xs">
                            <AnimatePresence mode='popLayout'>
                                {filteredUsers.map((user) => (
                                    <motion.tr
                                        layout
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        exit={{ opacity: 0, scale: 0.98 }}
                                        key={user.id}
                                        className="group hover:bg-gray-50/50 transition-all cursor-pointer"
                                    >
                                        <td className="px-4 sm:px-10 py-6 sm:py-8 whitespace-nowrap">
                                            <div className="flex items-center gap-3 sm:gap-5">
                                                <div className="h-9 w-9 sm:h-12 sm:w-12 bg-indigo-50 text-indigo-600 rounded-[1rem] sm:rounded-[1.2rem] flex items-center justify-center font-black text-[10px] sm:text-xs shadow-sm border border-indigo-100 uppercase shrink-0">
                                                    {user.name.split(' ').map(n => n[0]).join('')}
                                                </div>
                                                <div className="min-w-0">
                                                    <div className="font-black text-sm text-[#111827] uppercase tracking-tighter truncate">{user.name}</div>
                                                    <div className="text-[10px] text-gray-400 flex items-center gap-2 font-black uppercase tracking-widest mt-1 truncate">
                                                        <Mail size={12} className="text-gray-300 shrink-0" /> {user.email}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-4 sm:px-10 py-6 sm:py-8 whitespace-nowrap">
                                            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                                                <span className="font-black text-[11px] text-[#111827] uppercase tracking-tighter">{String(typeof user.role === 'object' ? (user.role?.name || 'N/A') : (user.role || 'N/A'))}</span>
                                                <div className="flex items-center gap-1.5 bg-gray-50 px-2 py-1 rounded-lg border border-gray-100 w-fit">
                                                    <div className={cn(
                                                        "h-1.5 w-1.5 rounded-full",
                                                        user.status === 'Active' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]' :
                                                            user.status === 'Away' ? 'bg-amber-400' : 'bg-rose-500'
                                                    )} />
                                                    <span className="font-black text-gray-600 tracking-widest uppercase text-[8px] sm:text-[9px]">{user.status}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-4 sm:px-10 py-6 sm:py-8">
                                            <div className="font-black text-xs text-[#111827] uppercase tracking-tighter truncate max-w-[120px]">{user.client}</div>
                                            <div className="text-[9px] text-indigo-500 mt-1 flex items-center gap-1.5 font-black uppercase tracking-widest truncate">
                                                <Briefcase size={12} className="text-indigo-300 shrink-0" /> {user.team}
                                            </div>
                                        </td>
                                        <td className="px-4 sm:px-10 py-6 sm:py-8 text-right">
                                            <button
                                                onClick={(e) => { e.stopPropagation(); openEditModal(user); }}
                                                className="inline-flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-indigo-50 text-indigo-600 border border-indigo-100 rounded-xl font-black text-[10px] sm:text-xs shadow-sm cursor-pointer hover:bg-indigo-100 transition-all whitespace-nowrap"
                                                title="Reconfigure Nodes"
                                            >
                                                <Globe size={14} className="text-indigo-500 hidden sm:block" />
                                                {user.assignedChannels} Nodes
                                            </button>
                                        </td>
                                        <td className="px-10 py-8 text-right">
                                            <div className="flex items-center justify-end gap-3">
                                                <button
                                                    onClick={() => openEditModal(user)}
                                                    className="p-3 bg-white border border-gray-100 rounded-xl text-gray-400 hover:text-indigo-600 hover:border-indigo-100 transition-all shadow-sm"
                                                    title="Modify Identity"
                                                >
                                                    <Edit size={16} strokeWidth={2.5} />
                                                </button>
                                                <button
                                                    onClick={() => {
                                                        if (window.confirm(`Are you sure you want to permanently delete ${user.name}?`)) {
                                                            toggleStatus.mutate(user.id)
                                                        }
                                                    }}
                                                    disabled={toggleStatus.isPending}
                                                    className="p-3 bg-white border border-gray-100 rounded-xl text-gray-400 hover:text-rose-600 hover:border-rose-100 transition-all shadow-sm disabled:opacity-50 inline-flex items-center gap-2"
                                                    title="Decommission User"
                                                >
                                                    <ShieldOff size={16} strokeWidth={2.5} className={toggleStatus.isPending ? "animate-pulse" : ""} />
                                                </button>
                                            </div>
                                        </td>
                                    </motion.tr>
                                ))}
                            </AnimatePresence>
                            {filteredUsers.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="px-10 py-32 text-center text-gray-400 italic">
                                        <div className="flex flex-col items-center gap-4">
                                            <Users size={48} className="text-gray-100" />
                                            <span className="text-xs font-black uppercase tracking-[0.3em]">No identities located in current subspace</span>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="p-10 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between mt-auto">
                    <p className="text-[10px] font-black text-gray-300 uppercase tracking-[0.3em]">System encrypted user registry</p>
                    <button 
                        onClick={() => { setSearchTerm(''); setRoleFilter('All Roles'); setCountryFilter('All Countries'); }}
                        className="px-5 py-2 bg-[#111827] text-white rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-black transition-all cursor-pointer shadow-lg active:scale-95"
                        title="Reset Filters to View All"
                    >
                        <UserCheck size={12} /> {users.filter(u => u.status === 'Active').length} Active Entities
                    </button>
                </div>
            </div>

            <AnimatePresence>
                {isModalOpen && (
                    <UserModal
                        isOpen={isModalOpen}
                        onClose={() => setIsModalOpen(false)}
                        user={selectedUser}
                        onSuccessRedirect={() => navigate('/super-admin')}
                    />
                )}
            </AnimatePresence>
        </div>
    )
}

export default GlobalUsers



