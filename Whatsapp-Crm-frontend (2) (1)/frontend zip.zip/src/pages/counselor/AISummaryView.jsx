import React, { useState } from 'react'
import { Search, Loader, Bot, Sparkles, Filter, ShieldCheck, Zap, X } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '../../lib/utils'
import { useQuery } from '@tanstack/react-query'
import api from '../../services/api'

const AISummaryView = () => {
    const [searchTerm, setSearchTerm] = useState('')
    const [refineMsg, setRefineMsg] = useState('')
    const [transcript, setTranscript] = useState(null)

    const { data: leads = [], isLoading, refetch, isFetching } = useQuery({
        queryKey: ['leads-ai-summary'],
        queryFn: async () => {
            const res = await api.get('/counselor/leads');
            const leadsArr = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : []);
            return leadsArr.map(l => ({
                id: l.id,
                leadName: l.name,
                country: l.country,
                score: l.score,
                category: l.score > 80 ? 'Hot' : l.score > 50 ? 'Warm' : 'Cold',
                program: l.program,
                budget: '$50k - $100k', // Mock field for now as not in schema
                intake: 'Sept 2024'     // Mock field for now as not in schema
            }));
        }
    })

    const summaryData = leads;

    const filteredData = summaryData.filter(s =>
        (s.leadName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (s.program || '').toLowerCase().includes(searchTerm.toLowerCase())
    )

    return (
        <div className="space-y-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-black text-[#111827] uppercase tracking-tighter flex items-center gap-3">
                        Machine Intelligence
                        <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-[9px] rounded-full uppercase tracking-widest shadow-sm">Beta</span>
                    </h1>
                    <p className="text-sm font-medium text-[#6B7280] mt-1">Review conversational AI qualification summaries and lead propensities.</p>
                </div>
                <div className="flex items-center gap-3">
                    <div className="flex flex-col items-end gap-1">
                        <button 
                            onClick={async () => {
                                setRefineMsg('')
                                await refetch()
                                setRefineMsg('Algorithm refined successfully!')
                                setTimeout(() => setRefineMsg(''), 3000)
                            }}
                            disabled={isFetching}
                            className="bg-[#111827] text-white px-5 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-indigo-100 flex items-center gap-2 disabled:opacity-75 active:scale-95"
                        >
                            {isFetching ? <Loader size={14} className="animate-spin" /> : <Sparkles size={14} />} 
                            Refine Algorithm
                        </button>
                        {refineMsg && <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest animate-pulse">{refineMsg}</span>}
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-3xl border border-[#E5E7EB] shadow-sm overflow-hidden flex flex-col">
                <div className="p-6 border-b border-[#E5E7EB] flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-gray-50/50 to-indigo-50/20">
                    <div className="flex items-center gap-4">
                        <h3 className="font-black text-[#111827] uppercase tracking-widest text-xs flex items-center gap-2">
                            <Bot size={14} className="text-indigo-500" /> Automated Extraction
                        </h3>
                    </div>
                    <div className="relative flex-1 sm:w-80 sm:flex-none">
                        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search summaries..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 outline-none transition-all shadow-sm"
                        />
                    </div>
                </div>

                <div className="overflow-x-auto min-h-[400px] bg-slate-50/30">
                    <div className="p-6">
                        {isLoading ? (
                            <div className="h-64 flex flex-col items-center justify-center text-indigo-600 opacity-50">
                                <Loader className="animate-spin mb-4" size={32} />
                                <p className="text-[10px] font-black uppercase tracking-widest">Parsing Intelligence Graphs...</p>
                            </div>
                        ) : filteredData.length === 0 ? (
                            <div className="h-64 flex flex-col items-center justify-center text-gray-400 opacity-50">
                                <Bot size={48} className="mb-4" />
                                <p className="text-[11px] font-black uppercase tracking-widest">No Intelligence Profiles Found.</p>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                                <AnimatePresence>
                                    {filteredData.map((data) => (
                                        <motion.div
                                            layout
                                            initial={{ opacity: 0, scale: 0.95 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            exit={{ opacity: 0, scale: 0.95 }}
                                            key={data.id}
                                            className="bg-white border border-gray-200 rounded-2xl shadow-sm hover:shadow-[0_8px_30px_rgb(0,0,0,0.04)] transition-all group overflow-hidden"
                                        >
                                            <div className="p-5 border-b border-gray-100 flex items-start justify-between bg-gradient-to-br from-white to-gray-50/50">
                                                <div className="flex items-center gap-3">
                                                    <div className="h-12 w-12 bg-gray-100 text-gray-700 rounded-2xl flex items-center justify-center font-black text-lg border border-gray-200 shadow-inner shrink-0">
                                                        {data.leadName.charAt(0)}
                                                    </div>
                                                    <div>
                                                        <h4 className="text-sm font-black text-[#111827] uppercase tracking-tight flex items-center gap-1.5">
                                                            {data.leadName}
                                                            {data.score > 80 && <ShieldCheck size={14} className="text-emerald-500" />}
                                                        </h4>
                                                        <div className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">{data.country}</div>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="inline-flex items-center gap-2">
                                                        <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Confidence Score</span>
                                                        <span className={cn(
                                                            "text-xl font-black bg-clip-text text-transparent",
                                                            data.score > 80 ? 'bg-gradient-to-r from-emerald-500 to-emerald-600' :
                                                                data.score > 50 ? 'bg-gradient-to-r from-amber-500 to-amber-600' :
                                                                    'bg-gradient-to-r from-indigo-500 to-indigo-600'
                                                        )}>
                                                            {data.score || '--'}
                                                        </span>
                                                    </div>
                                                    <div className="mt-1">
                                                        <span className={cn(
                                                            "text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-widest border",
                                                            data.category === 'Hot' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                                                                data.category === 'Warm' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                                                                    'bg-indigo-50 text-indigo-600 border-indigo-100'
                                                        )}>Propensity: {data.category}</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <div className="space-y-1">
                                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1"><Zap size={10} className="text-indigo-400" /> Target Context</span>
                                                    <p className="text-xs font-black text-[#111827]">{data.program}</p>
                                                </div>
                                                <div className="space-y-1">
                                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Financial Bandwidth</span>
                                                    <p className="text-xs font-black text-[#111827]">{data.budget}</p>
                                                </div>
                                                <div className="space-y-1">
                                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Enrollment Timeline</span>
                                                    <p className="text-xs font-black text-[#111827]">{data.intake}</p>
                                                </div>
                                                <div className="space-y-1">
                                                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Qualification Log</span>
                                                     <button 
                                                         onClick={() => setTranscript(data)}
                                                         className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest hover:underline hover:text-indigo-800 transition-all text-left"
                                                     >View full transcript →</button>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </AnimatePresence>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {/* Transcript Modal */}
            <AnimatePresence>
                {transcript && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
                        onClick={() => setTranscript(null)}
                    >
                        <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }}
                            onClick={e => e.stopPropagation()}
                            className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8 space-y-4"
                        >
                            <div className="flex justify-between items-center">
                                <h3 className="font-black text-[#111827] uppercase tracking-tighter">Qualification Log</h3>
                                <button onClick={() => setTranscript(null)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors"><X size={16} /></button>
                            </div>
                            <div className="space-y-2 text-xs text-gray-600">
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Lead:</span> {transcript.leadName}</p>
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Program:</span> {transcript.program || 'N/A'}</p>
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Country:</span> {transcript.country || 'N/A'}</p>
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Confidence Score:</span> {transcript.score || '--'}</p>
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Propensity:</span> {transcript.category}</p>
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Budget:</span> {transcript.budget}</p>
                                <p><span className="font-black uppercase text-gray-400 text-[9px] tracking-widest">Intake:</span> {transcript.intake}</p>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

export default AISummaryView



